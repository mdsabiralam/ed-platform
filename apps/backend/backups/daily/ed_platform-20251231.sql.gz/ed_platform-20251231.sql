--
-- PostgreSQL database dump
--

\restrict ALadYoNoPBiNVJHhinKlxJsbclGYdfyHZgVE6fofzmEh8GRBxEJ2YEoYOhGWiqc

-- Dumped from database version 16.9 (Debian 16.9-1.pgdg110+1)
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO admin;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: admin
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO admin;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: DayOfWeek; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public."DayOfWeek" AS ENUM (
    'MON',
    'TUE',
    'WED',
    'THU',
    'FRI',
    'SAT',
    'SUN'
);


ALTER TYPE public."DayOfWeek" OWNER TO admin;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public."UserRole" AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'TEACHER',
    'STUDENT',
    'PARENT',
    'HEADMASTER',
    'PRINCIPAL',
    'STAFF',
    'DRIVER',
    'AGENT',
    'CUSTOMER_CARE',
    'HOSTEL_SUPER',
    'LIBRARIAN',
    'SHOP_KEEPER',
    'MCM',
    'SUPPLIER'
);


ALTER TYPE public."UserRole" OWNER TO admin;

--
-- Name: get_current_user_id(); Type: FUNCTION; Schema: auth; Owner: admin
--

CREATE FUNCTION auth.get_current_user_id() RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN current_setting('request.jwt.claims', true)::jsonb ->> 'sub';
EXCEPTION
  WHEN OTHERS THEN RETURN NULL;
END;
$$;


ALTER FUNCTION auth.get_current_user_id() OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO admin;

--
-- Name: admission_sessions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.admission_sessions (
    id text NOT NULL,
    school_id text NOT NULL,
    name text NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.admission_sessions OWNER TO admin;

--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chart_of_accounts (
    id text NOT NULL,
    school_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.chart_of_accounts OWNER TO admin;

--
-- Name: class_recordings; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.class_recordings (
    id text NOT NULL,
    routine_entry_id text NOT NULL,
    vod_url text NOT NULL,
    duration integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.class_recordings OWNER TO admin;

--
-- Name: classes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.classes (
    id text NOT NULL,
    school_id text NOT NULL,
    name text NOT NULL,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.classes OWNER TO admin;

--
-- Name: global_configs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.global_configs (
    id text NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.global_configs OWNER TO admin;

--
-- Name: guardians; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.guardians (
    id text NOT NULL,
    user_id text NOT NULL
);


ALTER TABLE public.guardians OWNER TO admin;

--
-- Name: health_profiles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.health_profiles (
    id text NOT NULL,
    student_id text NOT NULL,
    blood_group text,
    allergies text,
    medical_history text,
    medications text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.health_profiles OWNER TO admin;

--
-- Name: kyc_documents; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.kyc_documents (
    id text NOT NULL,
    tenant_id text NOT NULL,
    document_type text NOT NULL,
    document_url text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    uploaded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    verified_at timestamp(3) without time zone,
    rejection_reason text
);


ALTER TABLE public.kyc_documents OWNER TO admin;

--
-- Name: leave_applications; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.leave_applications (
    id text NOT NULL,
    teacher_id text NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL
);


ALTER TABLE public.leave_applications OWNER TO admin;

--
-- Name: leave_types; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.leave_types (
    id text NOT NULL,
    school_id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    days_allowed integer DEFAULT 0 NOT NULL,
    is_paid boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.leave_types OWNER TO admin;

--
-- Name: live_attendance_logs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.live_attendance_logs (
    id text NOT NULL,
    student_id text NOT NULL,
    routine_entry_id text NOT NULL,
    join_time timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    leave_time timestamp(3) without time zone
);


ALTER TABLE public.live_attendance_logs OWNER TO admin;

--
-- Name: marketing_templates; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.marketing_templates (
    id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    content_html text NOT NULL,
    variables jsonb,
    thumbnail_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.marketing_templates OWNER TO admin;

--
-- Name: otp_logs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.otp_logs (
    id text NOT NULL,
    phone text NOT NULL,
    otp_code text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    is_used boolean DEFAULT false NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.otp_logs OWNER TO admin;

--
-- Name: parent_student_mappings; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.parent_student_mappings (
    id text NOT NULL,
    student_id text NOT NULL,
    guardian_id text NOT NULL,
    relationship text NOT NULL
);


ALTER TABLE public.parent_student_mappings OWNER TO admin;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.permissions (
    id text NOT NULL,
    action text NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.permissions OWNER TO admin;

--
-- Name: plans; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.plans (
    id text NOT NULL,
    name text NOT NULL,
    price_monthly double precision NOT NULL,
    features_config jsonb NOT NULL
);


ALTER TABLE public.plans OWNER TO admin;

--
-- Name: platform_admins; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.platform_admins (
    id text NOT NULL,
    user_id text NOT NULL,
    role text DEFAULT 'SUPER_ADMIN'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.platform_admins OWNER TO admin;

--
-- Name: platform_audit_logs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.platform_audit_logs (
    id text NOT NULL,
    admin_id text NOT NULL,
    action text NOT NULL,
    target text,
    details jsonb,
    ip_address text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.platform_audit_logs OWNER TO admin;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.profiles (
    profile_id text NOT NULL,
    user_id text NOT NULL,
    school_id text NOT NULL,
    role public."UserRole" NOT NULL
);


ALTER TABLE public.profiles OWNER TO admin;

--
-- Name: referral_linkages; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.referral_linkages (
    id text NOT NULL,
    reseller_id text NOT NULL,
    tenant_id text NOT NULL,
    referral_code text NOT NULL,
    linked_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.referral_linkages OWNER TO admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.refresh_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    token text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO admin;

--
-- Name: reseller_profiles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.reseller_profiles (
    id text NOT NULL,
    user_id text NOT NULL,
    commission_rate double precision DEFAULT 10.0 NOT NULL,
    total_earnings double precision DEFAULT 0.0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.reseller_profiles OWNER TO admin;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.role_permissions (
    id text NOT NULL,
    role public."UserRole" NOT NULL,
    permission_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO admin;

--
-- Name: rooms; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.rooms (
    id text NOT NULL,
    school_id text NOT NULL,
    name text NOT NULL,
    capacity integer NOT NULL,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.rooms OWNER TO admin;

--
-- Name: routine_entries; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.routine_entries (
    id text NOT NULL,
    class_id text NOT NULL,
    day_of_week public."DayOfWeek" NOT NULL,
    room_id text,
    school_id text NOT NULL,
    section_id text NOT NULL,
    slot_id text NOT NULL,
    subject_id text NOT NULL,
    teacher_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_live boolean DEFAULT false NOT NULL,
    meeting_link text,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.routine_entries OWNER TO admin;

--
-- Name: routine_substitutions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.routine_substitutions (
    id text NOT NULL,
    routine_entry_id text NOT NULL,
    substitute_teacher_id text,
    date timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    original_teacher_id text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL
);


ALTER TABLE public.routine_substitutions OWNER TO admin;

--
-- Name: saas_invoices; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.saas_invoices (
    id text NOT NULL,
    tenant_id text NOT NULL,
    amount double precision NOT NULL,
    status text NOT NULL,
    issued_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    paid_at timestamp(3) without time zone
);


ALTER TABLE public.saas_invoices OWNER TO admin;

--
-- Name: sections; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.sections (
    id text NOT NULL,
    class_id text NOT NULL,
    name text NOT NULL,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.sections OWNER TO admin;

--
-- Name: staff_extra_duty_logs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.staff_extra_duty_logs (
    id text NOT NULL,
    teacher_id text NOT NULL,
    hours_worked double precision NOT NULL,
    type text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    details jsonb
);


ALTER TABLE public.staff_extra_duty_logs OWNER TO admin;

--
-- Name: staff_profiles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.staff_profiles (
    id text NOT NULL,
    school_id text NOT NULL,
    user_id text NOT NULL,
    designation text NOT NULL,
    department text,
    joining_date timestamp(3) without time zone NOT NULL,
    deleted_at timestamp(3) without time zone,
    first_name text,
    last_name text
);


ALTER TABLE public.staff_profiles OWNER TO admin;

--
-- Name: student_sequences; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.student_sequences (
    id text NOT NULL,
    school_id text NOT NULL,
    year integer NOT NULL,
    last_seq integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.student_sequences OWNER TO admin;

--
-- Name: students; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.students (
    id text NOT NULL,
    school_id text NOT NULL,
    session_id text NOT NULL,
    section_id text NOT NULL,
    user_id text,
    first_name text NOT NULL,
    last_name text NOT NULL,
    admission_no text NOT NULL,
    roll_no integer,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.students OWNER TO admin;

--
-- Name: subjects; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.subjects (
    id text NOT NULL,
    name text NOT NULL,
    code text,
    school_id text NOT NULL,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.subjects OWNER TO admin;

--
-- Name: table_audit_logs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.table_audit_logs (
    id text NOT NULL,
    table_name text NOT NULL,
    record_id text,
    operation text NOT NULL,
    old_data jsonb,
    new_data jsonb,
    changed_by text,
    changed_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.table_audit_logs OWNER TO admin;

--
-- Name: tenant_subscriptions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.tenant_subscriptions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    plan_id text NOT NULL,
    start_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expiry_date timestamp(3) without time zone NOT NULL,
    auto_renew boolean DEFAULT true NOT NULL
);


ALTER TABLE public.tenant_subscriptions OWNER TO admin;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    subdomain text NOT NULL,
    logo_url text,
    is_active boolean DEFAULT true NOT NULL,
    subscription_status text DEFAULT 'ACTIVE'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.tenants OWNER TO admin;

--
-- Name: time_slots; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.time_slots (
    id text NOT NULL,
    school_id text NOT NULL,
    end_time text NOT NULL,
    start_time text NOT NULL,
    deleted_at timestamp(3) without time zone,
    label text,
    type text
);


ALTER TABLE public.time_slots OWNER TO admin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users (
    user_id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    phone text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.users OWNER TO admin;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
393c890b-2f41-47af-8c0c-5a1d6a646c42	db8228838bbfcccd741dc3c791bd3515686d9402c4cb564d6ad8c40ed2d3f183	2025-12-30 10:55:52.143337+00	20251230031728_timetable_comprehensive_fix	\N	\N	2025-12-30 10:55:52.082353+00	1
323a42b2-6fc0-491c-a690-53daa3918b1e	ef2a076c04742104f61204a572dc559711637ba75d79c8c1736949ced0313cd5	2025-12-30 10:55:51.2336+00	20251219202716_division_2_setup	\N	\N	2025-12-30 10:55:50.116071+00	1
200bce30-663a-4400-bc91-d6818b3198e4	c63ce7126dae265b8f54268464461e76a5268487107e834d8402adb9c0841d91	2025-12-30 10:55:51.249546+00	20251219204902_add_new_user_roles	\N	\N	2025-12-30 10:55:51.237652+00	1
8acea6e6-3f97-4706-adf4-2295c7cb292e	a684b303dff864bb52ca7f760283b0a84bfb777599d63a521a60e04be545cd74	2025-12-30 10:55:51.401969+00	20251219205607_add_more_user_roles	\N	\N	2025-12-30 10:55:51.314012+00	1
84051e79-527d-4342-b422-537bda536893	aac4ce193fb0365719f2876aef99500ce293a593cd7a96424f70ad7bec750fce	2025-12-30 10:55:52.156288+00	20251230035245_fix_timetable_compilation	\N	\N	2025-12-30 10:55:52.147007+00	1
e042b88f-3725-42dc-a269-0c8d14255a53	7aa5cade5c03be6af6c8b14f13fe931a20d61d3492e6c1eda8c91615efd607d4	2025-12-30 10:55:51.446526+00	20251219210604_add_platform_admin_and_configs	\N	\N	2025-12-30 10:55:51.406494+00	1
405704d3-4ba2-49ab-b1a4-94d758a3595b	36fdf21aa20c2ecf6051c81ee1c02c61d722457f8f33af62b4ad86c2e4242c30	2025-12-30 10:55:51.505713+00	20251219211428_add_audit_reseller_marketing_tables	\N	\N	2025-12-30 10:55:51.450149+00	1
d587d6a9-1578-4893-b24a-5dee4529f31b	d244a4a21c3c23d7fbb599e1844133a28088fbe4c288bda781dfe07c33d30d0b	2025-12-30 10:55:51.583996+00	20251220120300_add_permissions_and_otp_logs	\N	\N	2025-12-30 10:55:51.509283+00	1
72fd2bdb-b635-4975-9c0e-d84d27c6b8de	8d2684275e03f56556acf6faf4b2f51e878abc989e2cc4f97e6a9db2fd8ed763	2025-12-30 10:55:52.208388+00	20251230052935_add_student_sequence	\N	\N	2025-12-30 10:55:52.160379+00	1
548a407c-0e67-498e-80e8-1bbfbb009eb2	89f724c8f20208539032a898268a9f674e275bcf950b26e59ba873712ef11e06	2025-12-30 10:55:51.713473+00	20251220141656_add_finance_and_hr_schema	\N	\N	2025-12-30 10:55:51.588261+00	1
0133e018-3bf1-4a5a-93fa-82a07319928d	bc78bb286d4c552ac966c57c081bdc3b12773094987b3369b2c25c7d7f4ba3f4	2025-12-30 10:55:51.737858+00	20251220164306_add_encrypted_health_profiles	\N	\N	2025-12-30 10:55:51.716944+00	1
85d3a750-0aa1-41b8-94e0-f1a32aee79f7	3220b8604a9c3d7757d774a0170652834506e10ca5e0f5224a30d682bed4dda1	2025-12-30 10:55:51.782784+00	20251220172353_add_kyc_and_security_config	\N	\N	2025-12-30 10:55:51.743058+00	1
ea8aacef-6cb7-4b44-9a19-71c1f7a65f02	99838907f0d42d2ebdfc1a37805c47e33bbe86bba91641486b02e5607eae9c6a	2025-12-30 10:55:52.246749+00	20251230074923_add_live_class_fields	\N	\N	2025-12-30 10:55:52.213195+00	1
ff81a71a-8211-48b3-869f-feb4f0041d5a	97461941edf0603ea0c8f273d29b57156f1d394b0e382848573625f8fbe115b0	2025-12-30 10:55:51.838096+00	20251229171404_add_attendance_table	\N	\N	2025-12-30 10:55:51.786242+00	1
72f0d332-d8ff-4555-9e60-2e26f9e6b074	f0a1abba8d00d05c87443c3b6f0f9f6a3a7de51387280a21679bc945843ccd21	2025-12-30 10:55:51.884741+00	20251229181934_timetable_comprehensive_fix	\N	\N	2025-12-30 10:55:51.841399+00	1
4261e79d-ba22-43a1-8f40-e712e894fbec	e5a65b441f2e2e8915b9964e045f18fc96c21294c7e1d3c223a8a3cf7d0a83bf	2025-12-30 10:55:52.078392+00	20251229182815_add_homework_full	\N	\N	2025-12-30 10:55:51.888346+00	1
d1d6cb04-1b71-4c45-a0cb-d73c3d16f48a	3ad06aa18002435b3ca35d27a83dfe9ba4651fa3372d95d1c293c546fcdb9f86	2025-12-30 13:25:18.417863+00	20251230132518_add_substitution	\N	\N	2025-12-30 13:25:18.38759+00	1
c4ce9435-79a9-4f49-9581-922598a1929c	ce869e51e3c6a16fd6758c726db5953cb62a28787ee6076f2f7e4471beaf09f0	2025-12-30 15:26:29.882435+00	20251230152629_npm_run_buildnpm_run_start_dev	\N	\N	2025-12-30 15:26:29.831806+00	1
2078838a-1262-4842-8d48-502847830674	c665418e5b25d1f501cc39345e56db700dfa29db4a8f5a2c06403b38525609eb	2025-12-30 15:45:32.5861+00	20251230154532_module_14018127791801380371	\N	\N	2025-12-30 15:45:32.513707+00	1
ae08b1ad-1f06-48f6-827e-c0df5b19ffd4	5cbb2ce86996c5b9de83c3dbdce129f03da66ab81798f8dcdc6d8a28f5b25660	2025-12-30 16:59:49.245955+00	20251230165949_fix_eror	\N	\N	2025-12-30 16:59:49.141261+00	1
\.


--
-- Data for Name: admission_sessions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.admission_sessions (id, school_id, name, start_date, end_date, is_active, deleted_at) FROM stdin;
\.


--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chart_of_accounts (id, school_id, code, name, type, is_system, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: class_recordings; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.class_recordings (id, routine_entry_id, vod_url, duration, created_at) FROM stdin;
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.classes (id, school_id, name, deleted_at) FROM stdin;
\.


--
-- Data for Name: global_configs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.global_configs (id, key, value, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: guardians; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.guardians (id, user_id) FROM stdin;
\.


--
-- Data for Name: health_profiles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.health_profiles (id, student_id, blood_group, allergies, medical_history, medications, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: kyc_documents; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.kyc_documents (id, tenant_id, document_type, document_url, status, uploaded_at, verified_at, rejection_reason) FROM stdin;
\.


--
-- Data for Name: leave_applications; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.leave_applications (id, teacher_id, start_date, end_date, status) FROM stdin;
\.


--
-- Data for Name: leave_types; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.leave_types (id, school_id, name, code, days_allowed, is_paid, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: live_attendance_logs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.live_attendance_logs (id, student_id, routine_entry_id, join_time, leave_time) FROM stdin;
\.


--
-- Data for Name: marketing_templates; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.marketing_templates (id, name, category, content_html, variables, thumbnail_url, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: otp_logs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.otp_logs (id, phone, otp_code, expires_at, is_used, attempt_count, created_at) FROM stdin;
\.


--
-- Data for Name: parent_student_mappings; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.parent_student_mappings (id, student_id, guardian_id, relationship) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.permissions (id, action, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.plans (id, name, price_monthly, features_config) FROM stdin;
fb439194-94cf-48c8-893e-1137dc139667	Silver	2000	{"storage": "5GB", "students": 100}
e880ebf7-fea0-432a-8da2-47e52b58a24c	Gold	5000	{"storage": "20GB", "students": 500}
60ee21ae-bcad-4a23-be53-92415053c203	Platinum	10000	{"storage": "100GB", "students": "Unlimited"}
\.


--
-- Data for Name: platform_admins; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.platform_admins (id, user_id, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_audit_logs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.platform_audit_logs (id, admin_id, action, target, details, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.profiles (profile_id, user_id, school_id, role) FROM stdin;
\.


--
-- Data for Name: referral_linkages; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.referral_linkages (id, reseller_id, tenant_id, referral_code, linked_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.refresh_tokens (id, user_id, token, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: reseller_profiles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.reseller_profiles (id, user_id, commission_rate, total_earnings, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.role_permissions (id, role, permission_id, created_at) FROM stdin;
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.rooms (id, school_id, name, capacity, deleted_at) FROM stdin;
\.


--
-- Data for Name: routine_entries; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.routine_entries (id, class_id, day_of_week, room_id, school_id, section_id, slot_id, subject_id, teacher_id, created_at, is_live, meeting_link, updated_at) FROM stdin;
\.


--
-- Data for Name: routine_substitutions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.routine_substitutions (id, routine_entry_id, substitute_teacher_id, date, created_at, original_teacher_id, status) FROM stdin;
\.


--
-- Data for Name: saas_invoices; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.saas_invoices (id, tenant_id, amount, status, issued_at, paid_at) FROM stdin;
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.sections (id, class_id, name, deleted_at) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: staff_extra_duty_logs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.staff_extra_duty_logs (id, teacher_id, hours_worked, type, date, details) FROM stdin;
\.


--
-- Data for Name: staff_profiles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.staff_profiles (id, school_id, user_id, designation, department, joining_date, deleted_at, first_name, last_name) FROM stdin;
\.


--
-- Data for Name: student_sequences; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.student_sequences (id, school_id, year, last_seq) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.students (id, school_id, session_id, section_id, user_id, first_name, last_name, admission_no, roll_no, deleted_at) FROM stdin;
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.subjects (id, name, code, school_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: table_audit_logs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.table_audit_logs (id, table_name, record_id, operation, old_data, new_data, changed_by, changed_at) FROM stdin;
\.


--
-- Data for Name: tenant_subscriptions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.tenant_subscriptions (id, tenant_id, plan_id, start_date, expiry_date, auto_renew) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.tenants (id, name, subdomain, logo_url, is_active, subscription_status, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: time_slots; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.time_slots (id, school_id, end_time, start_time, deleted_at, label, type) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users (user_id, email, password_hash, phone, created_at, updated_at, deleted_at) FROM stdin;
7fd49017-92a0-405d-8737-f6e54049dfa7	admin@edplatform.com	$2b$10$1p5AxEi4XUpqkv6agYBdw.6wRjG5nbm7.EYPW1RP48Tn3ruhUfOym	+8801700000000	2025-12-30 10:55:59.962	2025-12-30 10:55:59.962	\N
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: admission_sessions admission_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.admission_sessions
    ADD CONSTRAINT admission_sessions_pkey PRIMARY KEY (id);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: class_recordings class_recordings_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.class_recordings
    ADD CONSTRAINT class_recordings_pkey PRIMARY KEY (id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: global_configs global_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.global_configs
    ADD CONSTRAINT global_configs_pkey PRIMARY KEY (id);


--
-- Name: guardians guardians_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.guardians
    ADD CONSTRAINT guardians_pkey PRIMARY KEY (id);


--
-- Name: health_profiles health_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.health_profiles
    ADD CONSTRAINT health_profiles_pkey PRIMARY KEY (id);


--
-- Name: kyc_documents kyc_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_pkey PRIMARY KEY (id);


--
-- Name: leave_applications leave_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.leave_applications
    ADD CONSTRAINT leave_applications_pkey PRIMARY KEY (id);


--
-- Name: leave_types leave_types_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT leave_types_pkey PRIMARY KEY (id);


--
-- Name: live_attendance_logs live_attendance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.live_attendance_logs
    ADD CONSTRAINT live_attendance_logs_pkey PRIMARY KEY (id);


--
-- Name: marketing_templates marketing_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.marketing_templates
    ADD CONSTRAINT marketing_templates_pkey PRIMARY KEY (id);


--
-- Name: otp_logs otp_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.otp_logs
    ADD CONSTRAINT otp_logs_pkey PRIMARY KEY (id);


--
-- Name: parent_student_mappings parent_student_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.parent_student_mappings
    ADD CONSTRAINT parent_student_mappings_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: platform_admins platform_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.platform_admins
    ADD CONSTRAINT platform_admins_pkey PRIMARY KEY (id);


--
-- Name: platform_audit_logs platform_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.platform_audit_logs
    ADD CONSTRAINT platform_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (profile_id);


--
-- Name: referral_linkages referral_linkages_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.referral_linkages
    ADD CONSTRAINT referral_linkages_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: reseller_profiles reseller_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.reseller_profiles
    ADD CONSTRAINT reseller_profiles_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: routine_entries routine_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_entries
    ADD CONSTRAINT routine_entries_pkey PRIMARY KEY (id);


--
-- Name: routine_substitutions routine_substitutions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_substitutions
    ADD CONSTRAINT routine_substitutions_pkey PRIMARY KEY (id);


--
-- Name: saas_invoices saas_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saas_invoices
    ADD CONSTRAINT saas_invoices_pkey PRIMARY KEY (id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: staff_extra_duty_logs staff_extra_duty_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.staff_extra_duty_logs
    ADD CONSTRAINT staff_extra_duty_logs_pkey PRIMARY KEY (id);


--
-- Name: staff_profiles staff_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.staff_profiles
    ADD CONSTRAINT staff_profiles_pkey PRIMARY KEY (id);


--
-- Name: student_sequences student_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.student_sequences
    ADD CONSTRAINT student_sequences_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: table_audit_logs table_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.table_audit_logs
    ADD CONSTRAINT table_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: tenant_subscriptions tenant_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: time_slots time_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.time_slots
    ADD CONSTRAINT time_slots_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: chart_of_accounts_school_id_code_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX chart_of_accounts_school_id_code_key ON public.chart_of_accounts USING btree (school_id, code);


--
-- Name: global_configs_key_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX global_configs_key_key ON public.global_configs USING btree (key);


--
-- Name: guardians_user_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX guardians_user_id_key ON public.guardians USING btree (user_id);


--
-- Name: health_profiles_student_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX health_profiles_student_id_key ON public.health_profiles USING btree (student_id);


--
-- Name: leave_types_school_id_code_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX leave_types_school_id_code_key ON public.leave_types USING btree (school_id, code);


--
-- Name: parent_student_mappings_student_id_guardian_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX parent_student_mappings_student_id_guardian_id_key ON public.parent_student_mappings USING btree (student_id, guardian_id);


--
-- Name: permissions_action_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX permissions_action_key ON public.permissions USING btree (action);


--
-- Name: plans_name_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX plans_name_key ON public.plans USING btree (name);


--
-- Name: platform_admins_user_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX platform_admins_user_id_key ON public.platform_admins USING btree (user_id);


--
-- Name: profiles_user_id_school_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX profiles_user_id_school_id_key ON public.profiles USING btree (user_id, school_id);


--
-- Name: referral_linkages_tenant_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX referral_linkages_tenant_id_key ON public.referral_linkages USING btree (tenant_id);


--
-- Name: refresh_tokens_token_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX refresh_tokens_token_key ON public.refresh_tokens USING btree (token);


--
-- Name: reseller_profiles_user_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX reseller_profiles_user_id_key ON public.reseller_profiles USING btree (user_id);


--
-- Name: role_permissions_role_permission_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX role_permissions_role_permission_id_key ON public.role_permissions USING btree (role, permission_id);


--
-- Name: staff_profiles_user_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX staff_profiles_user_id_key ON public.staff_profiles USING btree (user_id);


--
-- Name: student_sequences_school_id_year_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX student_sequences_school_id_year_key ON public.student_sequences USING btree (school_id, year);


--
-- Name: students_admission_no_school_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX students_admission_no_school_id_key ON public.students USING btree (admission_no, school_id);


--
-- Name: students_user_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX students_user_id_key ON public.students USING btree (user_id);


--
-- Name: tenant_subscriptions_tenant_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX tenant_subscriptions_tenant_id_key ON public.tenant_subscriptions USING btree (tenant_id);


--
-- Name: tenants_subdomain_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX tenants_subdomain_key ON public.tenants USING btree (subdomain);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: admission_sessions admission_sessions_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.admission_sessions
    ADD CONSTRAINT admission_sessions_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chart_of_accounts chart_of_accounts_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: class_recordings class_recordings_routine_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.class_recordings
    ADD CONSTRAINT class_recordings_routine_entry_id_fkey FOREIGN KEY (routine_entry_id) REFERENCES public.routine_entries(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: classes classes_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: guardians guardians_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.guardians
    ADD CONSTRAINT guardians_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: health_profiles health_profiles_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.health_profiles
    ADD CONSTRAINT health_profiles_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kyc_documents kyc_documents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: leave_applications leave_applications_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.leave_applications
    ADD CONSTRAINT leave_applications_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.staff_profiles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: leave_types leave_types_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT leave_types_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: live_attendance_logs live_attendance_logs_routine_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.live_attendance_logs
    ADD CONSTRAINT live_attendance_logs_routine_entry_id_fkey FOREIGN KEY (routine_entry_id) REFERENCES public.routine_entries(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: live_attendance_logs live_attendance_logs_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.live_attendance_logs
    ADD CONSTRAINT live_attendance_logs_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: parent_student_mappings parent_student_mappings_guardian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.parent_student_mappings
    ADD CONSTRAINT parent_student_mappings_guardian_id_fkey FOREIGN KEY (guardian_id) REFERENCES public.guardians(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: parent_student_mappings parent_student_mappings_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.parent_student_mappings
    ADD CONSTRAINT parent_student_mappings_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: platform_admins platform_admins_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.platform_admins
    ADD CONSTRAINT platform_admins_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: platform_audit_logs platform_audit_logs_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.platform_audit_logs
    ADD CONSTRAINT platform_audit_logs_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.platform_admins(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: profiles profiles_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: profiles profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: referral_linkages referral_linkages_reseller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.referral_linkages
    ADD CONSTRAINT referral_linkages_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES public.reseller_profiles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: referral_linkages referral_linkages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.referral_linkages
    ADD CONSTRAINT referral_linkages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reseller_profiles reseller_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.reseller_profiles
    ADD CONSTRAINT reseller_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rooms rooms_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: routine_entries routine_entries_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_entries
    ADD CONSTRAINT routine_entries_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: routine_entries routine_entries_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_entries
    ADD CONSTRAINT routine_entries_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: routine_entries routine_entries_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_entries
    ADD CONSTRAINT routine_entries_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: routine_entries routine_entries_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_entries
    ADD CONSTRAINT routine_entries_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.sections(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: routine_entries routine_entries_slot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_entries
    ADD CONSTRAINT routine_entries_slot_id_fkey FOREIGN KEY (slot_id) REFERENCES public.time_slots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: routine_entries routine_entries_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_entries
    ADD CONSTRAINT routine_entries_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: routine_entries routine_entries_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_entries
    ADD CONSTRAINT routine_entries_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.staff_profiles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: routine_substitutions routine_substitutions_original_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_substitutions
    ADD CONSTRAINT routine_substitutions_original_teacher_id_fkey FOREIGN KEY (original_teacher_id) REFERENCES public.staff_profiles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: routine_substitutions routine_substitutions_routine_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_substitutions
    ADD CONSTRAINT routine_substitutions_routine_entry_id_fkey FOREIGN KEY (routine_entry_id) REFERENCES public.routine_entries(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: routine_substitutions routine_substitutions_substitute_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.routine_substitutions
    ADD CONSTRAINT routine_substitutions_substitute_teacher_id_fkey FOREIGN KEY (substitute_teacher_id) REFERENCES public.staff_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: saas_invoices saas_invoices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saas_invoices
    ADD CONSTRAINT saas_invoices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sections sections_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: staff_extra_duty_logs staff_extra_duty_logs_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.staff_extra_duty_logs
    ADD CONSTRAINT staff_extra_duty_logs_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.staff_profiles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: staff_profiles staff_profiles_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.staff_profiles
    ADD CONSTRAINT staff_profiles_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: staff_profiles staff_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.staff_profiles
    ADD CONSTRAINT staff_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: students students_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: students students_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.sections(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: students students_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.admission_sessions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: students students_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: subjects subjects_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tenant_subscriptions tenant_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tenant_subscriptions tenant_subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: time_slots time_slots_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.time_slots
    ADD CONSTRAINT time_slots_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: admin
--

GRANT USAGE ON SCHEMA auth TO app_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: admin
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict ALadYoNoPBiNVJHhinKlxJsbclGYdfyHZgVE6fofzmEh8GRBxEJ2YEoYOhGWiqc

