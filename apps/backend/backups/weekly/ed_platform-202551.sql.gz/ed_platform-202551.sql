--
-- PostgreSQL database dump
--

\restrict b0HUP6Q6qIEv9XeJhrK376QTWcl9oPjQleNN5G8y9mX8XGgj3pVggUdhTIIFdIB

-- Dumped from database version 16.9 (Debian 16.9-1.pgdg110+1)
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO admin;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public."UserRole" AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'TEACHER',
    'STUDENT',
    'PARENT',
    'HEADMASTER',
    'PRINCIPAL',
    'STAFF',
    'DRIVER',
    'AGENT',
    'CUSTOMER_CARE',
    'HOSTEL_SUPER',
    'LIBRARIAN',
    'SHOP_KEEPER',
    'MCM',
    'SUPPLIER'
);


ALTER TYPE public."UserRole" OWNER TO admin;

--
-- Name: get_current_user_id(); Type: FUNCTION; Schema: auth; Owner: admin
--

CREATE FUNCTION auth.get_current_user_id() RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN current_setting('request.jwt.claims', true)::jsonb ->> 'sub';
EXCEPTION
  WHEN OTHERS THEN RETURN NULL;
END;
$$;


ALTER FUNCTION auth.get_current_user_id() OWNER TO admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO admin;

--
-- Name: global_configs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.global_configs (
    id text NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.global_configs OWNER TO admin;

--
-- Name: marketing_templates; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.marketing_templates (
    id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    content_html text NOT NULL,
    variables jsonb,
    thumbnail_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.marketing_templates OWNER TO admin;

--
-- Name: plans; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.plans (
    id text NOT NULL,
    name text NOT NULL,
    price_monthly double precision NOT NULL,
    features_config jsonb NOT NULL
);


ALTER TABLE public.plans OWNER TO admin;

--
-- Name: platform_admins; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.platform_admins (
    id text NOT NULL,
    user_id text NOT NULL,
    role text DEFAULT 'SUPER_ADMIN'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.platform_admins OWNER TO admin;

--
-- Name: platform_audit_logs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.platform_audit_logs (
    id text NOT NULL,
    admin_id text NOT NULL,
    action text NOT NULL,
    target text,
    details jsonb,
    ip_address text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.platform_audit_logs OWNER TO admin;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.profiles (
    profile_id text NOT NULL,
    user_id text NOT NULL,
    school_id text NOT NULL,
    role public."UserRole" NOT NULL
);


ALTER TABLE public.profiles OWNER TO admin;

--
-- Name: referral_linkages; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.referral_linkages (
    id text NOT NULL,
    reseller_id text NOT NULL,
    tenant_id text NOT NULL,
    referral_code text NOT NULL,
    linked_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.referral_linkages OWNER TO admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.refresh_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    token text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO admin;

--
-- Name: reseller_profiles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.reseller_profiles (
    id text NOT NULL,
    user_id text NOT NULL,
    commission_rate double precision DEFAULT 10.0 NOT NULL,
    total_earnings double precision DEFAULT 0.0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.reseller_profiles OWNER TO admin;

--
-- Name: saas_invoices; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.saas_invoices (
    id text NOT NULL,
    tenant_id text NOT NULL,
    amount double precision NOT NULL,
    status text NOT NULL,
    issued_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    paid_at timestamp(3) without time zone
);


ALTER TABLE public.saas_invoices OWNER TO admin;

--
-- Name: tenant_subscriptions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.tenant_subscriptions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    plan_id text NOT NULL,
    start_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expiry_date timestamp(3) without time zone NOT NULL,
    auto_renew boolean DEFAULT true NOT NULL
);


ALTER TABLE public.tenant_subscriptions OWNER TO admin;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    subdomain text NOT NULL,
    logo_url text,
    is_active boolean DEFAULT true NOT NULL,
    subscription_status text DEFAULT 'ACTIVE'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO admin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users (
    user_id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    phone text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO admin;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
dd18a256-d0e3-4337-8d0f-223e93ed3d3b	ef2a076c04742104f61204a572dc559711637ba75d79c8c1736949ced0313cd5	2025-12-19 20:27:17.240293+00	20251219202716_division_2_setup	\N	\N	2025-12-19 20:27:16.500587+00	1
36b0776a-e02a-445e-ae92-6f06af0df1d2	c63ce7126dae265b8f54268464461e76a5268487107e834d8402adb9c0841d91	2025-12-19 20:49:02.109712+00	20251219204902_add_new_user_roles	\N	\N	2025-12-19 20:49:02.095641+00	1
06a91dfa-e1de-45b5-97bf-70e26d107380	a684b303dff864bb52ca7f760283b0a84bfb777599d63a521a60e04be545cd74	2025-12-19 20:56:07.064874+00	20251219205607_add_more_user_roles	\N	\N	2025-12-19 20:56:07.051497+00	1
8de9be82-a192-4862-b3e2-42e16862eff2	7aa5cade5c03be6af6c8b14f13fe931a20d61d3492e6c1eda8c91615efd607d4	2025-12-19 21:06:04.242509+00	20251219210604_add_platform_admin_and_configs	\N	\N	2025-12-19 21:06:04.186719+00	1
870ae854-df15-408c-b457-741d43d770dd	36fdf21aa20c2ecf6051c81ee1c02c61d722457f8f33af62b4ad86c2e4242c30	2025-12-19 21:14:28.64026+00	20251219211428_add_audit_reseller_marketing_tables	\N	\N	2025-12-19 21:14:28.564293+00	1
\.


--
-- Data for Name: global_configs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.global_configs (id, key, value, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: marketing_templates; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.marketing_templates (id, name, category, content_html, variables, thumbnail_url, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.plans (id, name, price_monthly, features_config) FROM stdin;
b7ef5156-dec6-48cc-9da1-02984383bd19	Silver	2000	{"storage": "5GB", "students": 100}
3d3b2acb-712f-4863-846b-771176b623c1	Gold	5000	{"storage": "20GB", "students": 500}
60e956a4-404e-4d17-a73d-2ac4e7d2cfe8	Platinum	10000	{"storage": "100GB", "students": "Unlimited"}
a42c2d50-966c-44d7-bd0b-8515af91686f		0	{}
\.


--
-- Data for Name: platform_admins; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.platform_admins (id, user_id, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_audit_logs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.platform_audit_logs (id, admin_id, action, target, details, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.profiles (profile_id, user_id, school_id, role) FROM stdin;
\.


--
-- Data for Name: referral_linkages; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.referral_linkages (id, reseller_id, tenant_id, referral_code, linked_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.refresh_tokens (id, user_id, token, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: reseller_profiles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.reseller_profiles (id, user_id, commission_rate, total_earnings, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: saas_invoices; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.saas_invoices (id, tenant_id, amount, status, issued_at, paid_at) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: tenant_subscriptions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.tenant_subscriptions (id, tenant_id, plan_id, start_date, expiry_date, auto_renew) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.tenants (id, name, subdomain, logo_url, is_active, subscription_status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users (user_id, email, password_hash, phone, created_at, updated_at) FROM stdin;
f4a11292-2a26-4a7d-9792-2d0ab9483ea5	admin@edplatform.com	$2b$10$n2DooVBv1VvcSajXt2EBoeIcTU6FbQOAVgKuGi3cIdxhBzxJhZncq	+8801700000000	2025-12-19 20:27:28.2	2025-12-19 20:27:28.2
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: global_configs global_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.global_configs
    ADD CONSTRAINT global_configs_pkey PRIMARY KEY (id);


--
-- Name: marketing_templates marketing_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.marketing_templates
    ADD CONSTRAINT marketing_templates_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: platform_admins platform_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.platform_admins
    ADD CONSTRAINT platform_admins_pkey PRIMARY KEY (id);


--
-- Name: platform_audit_logs platform_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.platform_audit_logs
    ADD CONSTRAINT platform_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (profile_id);


--
-- Name: referral_linkages referral_linkages_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.referral_linkages
    ADD CONSTRAINT referral_linkages_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: reseller_profiles reseller_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.reseller_profiles
    ADD CONSTRAINT reseller_profiles_pkey PRIMARY KEY (id);


--
-- Name: saas_invoices saas_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saas_invoices
    ADD CONSTRAINT saas_invoices_pkey PRIMARY KEY (id);


--
-- Name: tenant_subscriptions tenant_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: global_configs_key_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX global_configs_key_key ON public.global_configs USING btree (key);


--
-- Name: plans_name_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX plans_name_key ON public.plans USING btree (name);


--
-- Name: platform_admins_user_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX platform_admins_user_id_key ON public.platform_admins USING btree (user_id);


--
-- Name: profiles_user_id_school_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX profiles_user_id_school_id_key ON public.profiles USING btree (user_id, school_id);


--
-- Name: referral_linkages_tenant_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX referral_linkages_tenant_id_key ON public.referral_linkages USING btree (tenant_id);


--
-- Name: refresh_tokens_token_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX refresh_tokens_token_key ON public.refresh_tokens USING btree (token);


--
-- Name: reseller_profiles_user_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX reseller_profiles_user_id_key ON public.reseller_profiles USING btree (user_id);


--
-- Name: tenant_subscriptions_tenant_id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX tenant_subscriptions_tenant_id_key ON public.tenant_subscriptions USING btree (tenant_id);


--
-- Name: tenants_subdomain_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX tenants_subdomain_key ON public.tenants USING btree (subdomain);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: global_configs update_global_configs_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER update_global_configs_updated_at BEFORE UPDATE ON public.global_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: marketing_templates update_marketing_templates_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER update_marketing_templates_updated_at BEFORE UPDATE ON public.marketing_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: platform_admins update_platform_admins_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER update_platform_admins_updated_at BEFORE UPDATE ON public.platform_admins FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: reseller_profiles update_reseller_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER update_reseller_profiles_updated_at BEFORE UPDATE ON public.reseller_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tenants update_tenants_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER update_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: platform_admins platform_admins_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.platform_admins
    ADD CONSTRAINT platform_admins_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: platform_audit_logs platform_audit_logs_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.platform_audit_logs
    ADD CONSTRAINT platform_audit_logs_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.platform_admins(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: profiles profiles_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: profiles profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: referral_linkages referral_linkages_reseller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.referral_linkages
    ADD CONSTRAINT referral_linkages_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES public.reseller_profiles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: referral_linkages referral_linkages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.referral_linkages
    ADD CONSTRAINT referral_linkages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reseller_profiles reseller_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.reseller_profiles
    ADD CONSTRAINT reseller_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: saas_invoices saas_invoices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saas_invoices
    ADD CONSTRAINT saas_invoices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tenant_subscriptions tenant_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tenant_subscriptions tenant_subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: profiles Admins can view profiles in their tenant; Type: POLICY; Schema: public; Owner: admin
--

CREATE POLICY "Admins can view profiles in their tenant" ON public.profiles FOR SELECT TO authenticated USING ((school_id IN ( SELECT profiles_1.school_id
   FROM public.profiles profiles_1
  WHERE ((profiles_1.user_id = auth.get_current_user_id()) AND (profiles_1.role = 'ADMIN'::public."UserRole")))));


--
-- Name: saas_invoices Admins can view their own invoices; Type: POLICY; Schema: public; Owner: admin
--

CREATE POLICY "Admins can view their own invoices" ON public.saas_invoices FOR SELECT TO authenticated USING ((tenant_id IN ( SELECT profiles.school_id
   FROM public.profiles
  WHERE ((profiles.user_id = auth.get_current_user_id()) AND (profiles.role = 'ADMIN'::public."UserRole")))));


--
-- Name: profiles Allow full access to service_role on profiles; Type: POLICY; Schema: public; Owner: admin
--

CREATE POLICY "Allow full access to service_role on profiles" ON public.profiles TO service_role USING (true) WITH CHECK (true);


--
-- Name: saas_invoices Allow full access to service_role on saas_invoices; Type: POLICY; Schema: public; Owner: admin
--

CREATE POLICY "Allow full access to service_role on saas_invoices" ON public.saas_invoices TO service_role USING (true) WITH CHECK (true);


--
-- Name: tenants Allow full access to service_role on tenants; Type: POLICY; Schema: public; Owner: admin
--

CREATE POLICY "Allow full access to service_role on tenants" ON public.tenants TO service_role USING (true) WITH CHECK (true);


--
-- Name: users Allow full access to service_role on users; Type: POLICY; Schema: public; Owner: admin
--

CREATE POLICY "Allow full access to service_role on users" ON public.users TO service_role USING (true) WITH CHECK (true);


--
-- Name: users Users can manage their own user record; Type: POLICY; Schema: public; Owner: admin
--

CREATE POLICY "Users can manage their own user record" ON public.users TO authenticated USING ((user_id = auth.get_current_user_id())) WITH CHECK ((user_id = auth.get_current_user_id()));


--
-- Name: profiles Users can view their own profiles; Type: POLICY; Schema: public; Owner: admin
--

CREATE POLICY "Users can view their own profiles" ON public.profiles FOR SELECT TO authenticated USING ((user_id = auth.get_current_user_id()));


--
-- Name: tenants Users can view their own tenant; Type: POLICY; Schema: public; Owner: admin
--

CREATE POLICY "Users can view their own tenant" ON public.tenants FOR SELECT TO authenticated USING ((id = ( SELECT profiles.school_id
   FROM public.profiles
  WHERE (profiles.user_id = auth.get_current_user_id())
 LIMIT 1)));


--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: admin
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: saas_invoices; Type: ROW SECURITY; Schema: public; Owner: admin
--

ALTER TABLE public.saas_invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_subscriptions; Type: ROW SECURITY; Schema: public; Owner: admin
--

ALTER TABLE public.tenant_subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: admin
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: admin
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: admin
--

GRANT USAGE ON SCHEMA auth TO app_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;
GRANT USAGE ON SCHEMA public TO app_user;


--
-- Name: TABLE _prisma_migrations; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public._prisma_migrations TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public._prisma_migrations TO app_user;


--
-- Name: TABLE geography_columns; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.geography_columns TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.geography_columns TO app_user;


--
-- Name: TABLE geometry_columns; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.geometry_columns TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.geometry_columns TO app_user;


--
-- Name: TABLE global_configs; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.global_configs TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.global_configs TO app_user;


--
-- Name: TABLE marketing_templates; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.marketing_templates TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.marketing_templates TO app_user;


--
-- Name: TABLE plans; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.plans TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.plans TO app_user;


--
-- Name: TABLE platform_admins; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.platform_admins TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.platform_admins TO app_user;


--
-- Name: TABLE platform_audit_logs; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.platform_audit_logs TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.platform_audit_logs TO app_user;


--
-- Name: TABLE profiles; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.profiles TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.profiles TO app_user;


--
-- Name: TABLE referral_linkages; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.referral_linkages TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.referral_linkages TO app_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.refresh_tokens TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.refresh_tokens TO app_user;


--
-- Name: TABLE reseller_profiles; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.reseller_profiles TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.reseller_profiles TO app_user;


--
-- Name: TABLE saas_invoices; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.saas_invoices TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.saas_invoices TO app_user;


--
-- Name: TABLE spatial_ref_sys; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.spatial_ref_sys TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.spatial_ref_sys TO app_user;


--
-- Name: TABLE tenant_subscriptions; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.tenant_subscriptions TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tenant_subscriptions TO app_user;


--
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.tenants TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tenants TO app_user;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.users TO service_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO app_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE admin IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES TO app_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE admin IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO app_user;


--
-- PostgreSQL database dump complete
--

\unrestrict b0HUP6Q6qIEv9XeJhrK376QTWcl9oPjQleNN5G8y9mX8XGgj3pVggUdhTIIFdIB

